"""
Flask API Web Application for Horse Racing AI Prediction System.
"""

import os
import sys

from pathlib import Path

# Ensure repository root and src directory are in sys.path across all platforms and execution environments
APP_DIR = str(Path(__file__).resolve().parent)
SRC_DIR = os.path.join(APP_DIR, "src")

if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

from flask import Flask, jsonify, request, render_template
from typing import Dict, Any, List

try:
    from src.models import RaceInfo, HorseEntry
    from src.data import get_sample_races, generate_synthetic_historical_data
    from src.predictor import HorseRacePredictor
    from src.strategy import calculate_betting_recommendations
    from src.jra_importer import parse_jra_text, fetch_and_parse_jra_url, fetch_this_weeks_jra_races
    from src.db import init_db, save_race, get_race_by_id, list_all_races
except (ImportError, ModuleNotFoundError):
    try:
        from models import RaceInfo, HorseEntry
        from data import get_sample_races, generate_synthetic_historical_data
        from predictor import HorseRacePredictor
        from strategy import calculate_betting_recommendations
        from jra_importer import parse_jra_text, fetch_and_parse_jra_url, fetch_this_weeks_jra_races
        from db import init_db, save_race, get_race_by_id, list_all_races
    except (ImportError, ModuleNotFoundError) as e:
        print(f"[ERROR] Required modules in 'src/' folder could not be loaded: {e}")
        print(f"[ERROR] Please ensure 'c:\\app\\jules_keiba\\src' directory exists and contains models.py, data.py, predictor.py, strategy.py, jra_importer.py, db.py")
        sys.exit(1)

app = Flask(__name__)
predictor = HorseRacePredictor()

# Initialize Database
init_db()

# Pre-populate sample races in DB if empty
sample_races_cache = {r.race_id: r for r in get_sample_races()}
for s_race in sample_races_cache.values():
    if not get_race_by_id(s_race.race_id):
        save_race(s_race)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/races", methods=["GET"])
def list_races():
    try:
        db_races = list_all_races()
        return jsonify({"status": "success", "races": db_races})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/api/races/<race_id>", methods=["GET"])
def get_race_detail(race_id: str):
    race = get_race_by_id(race_id)
    if not race:
        race = sample_races_cache.get(race_id)
    if not race:
        return jsonify({"status": "error", "message": "Race not found"}), 404
    return jsonify({"status": "success", "race": race.to_dict()})

@app.route("/api/import_weekly_jra", methods=["POST"])
def import_weekly_jra():
    try:
        races = fetch_this_weeks_jra_races()
        processed_results = []
        for race in races:
            save_race(race)
            predictions = predictor.predict_race(race)
            recommendations = calculate_betting_recommendations(predictions)
            processed_results.append({
                "race": race.to_dict(),
                "predictions": predictions,
                "recommendations": recommendations
            })

        return jsonify({
            "status": "success",
            "message": f"今週のJRA出馬表データ ({len(races)}レース) を自動取得し、全レースの予想を完了しました。",
            "count": len(races),
            "results": processed_results
        })
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/api/import_jra", methods=["POST"])
def import_jra():
    data = request.get_json() or {}
    url = data.get("url")
    text_content = data.get("text_content")
    race_name = data.get("race_name")

    try:
        if url:
            race = fetch_and_parse_jra_url(url)
        elif text_content:
            race = parse_jra_text(text_content, race_name_override=race_name)
        else:
            return jsonify({"status": "error", "message": "url または text_content が必要です。"}), 400

        # Save to SQLite Database for persistent storage
        save_race(race)

        predictions = predictor.predict_race(race)
        recommendations = calculate_betting_recommendations(predictions)

        return jsonify({
            "status": "success",
            "message": "JRA出馬表を取り込み、データベースに保存しました。",
            "race": race.to_dict(),
            "predictions": predictions,
            "recommendations": recommendations
        })
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/api/predict", methods=["POST"])
def predict_race():
    data = request.get_json()
    if not data or "horses" not in data:
        return jsonify({"status": "error", "message": "Invalid payload: horses list required"}), 400

    try:
        horses = []
        for h in data["horses"]:
            horses.append(HorseEntry(
                horse_number=int(h["horse_number"]),
                horse_name=str(h["horse_name"]),
                jockey_name=str(h.get("jockey_name", "未定")),
                trainer_name=str(h.get("trainer_name", "未定")),
                age=int(h.get("age", 4)),
                weight=float(h.get("weight", 480)),
                impost=float(h.get("impost", 57.0)),
                past_speed_rating=float(h.get("past_speed_rating", 75.0)),
                past_win_rate=float(h.get("past_win_rate", 0.2)),
                jockey_win_rate=float(h.get("jockey_win_rate", 0.15)),
                trainer_win_rate=float(h.get("trainer_win_rate", 0.15)),
                track_aptitude=float(h.get("track_aptitude", 0.8)),
                odds=float(h.get("odds", 5.0))
            ))

        race = RaceInfo(
            race_id=data.get("race_id", "CUSTOM_01"),
            race_name=data.get("race_name", "カスタム予想レース"),
            track_name=data.get("track_name", "東京"),
            surface_type=data.get("surface_type", "芝"),
            distance=int(data.get("distance", 2000)),
            track_condition=data.get("track_condition", "良"),
            weather=data.get("weather", "晴"),
            horses=horses
        )

        # Save to SQLite DB
        save_race(race)

        predictions = predictor.predict_race(race)
        recommendations = calculate_betting_recommendations(predictions)

        return jsonify({
            "status": "success",
            "race": race.to_dict(),
            "predictions": predictions,
            "recommendations": recommendations
        })

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/api/train", methods=["POST"])
def retrain_model():
    try:
        synth_df = generate_synthetic_historical_data(num_races=300)
        predictor.train(synth_df)
        return jsonify({"status": "success", "message": f"AI Precision Model retrained successfully on {len(synth_df)} data points."})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

if __name__ == "__main__":
    import socket

    port = int(os.environ.get("PORT", 5001))

    def is_port_in_use(p):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            return s.connect_ex(('127.0.0.1', p)) == 0

    if is_port_in_use(port):
        print(f"Port {port} is already in use. Searching for an available port...")
        for alt_port in range(5002, 5020):
            if not is_port_in_use(alt_port):
                port = alt_port
                break

    print(f"Starting server on http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=True)
